Write in each console the follow line before launching
source devel/setup.bash

To launch localization
roslaunch mobile_robot_navigation_project slamgmapping.launch

To launch urdf of husky etc in rviz
roslaunch mobile_robot_navigation_project rvizcontroller.launch

To launch the handshake between unity and ros
roslaunch mobile_robot_navigation_project navigation.launch

To navigate
roslaunch mobile_robot_navigation_project movebase.launch


