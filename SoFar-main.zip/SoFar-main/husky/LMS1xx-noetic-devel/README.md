LMS1xx [![Build Status](https://travis-ci.org/clearpathrobotics/LMS1xx.svg?branch=master)](https://travis-ci.org/clearpathrobotics/LMS1xx)
======

ROS driver for the SICK LMS1xx family of laser scanners. Originally from [RCPRG](https://github.com/RCPRG-ros-pkg/RCPRG_laser_drivers).
